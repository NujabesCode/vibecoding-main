# 우리반 캠퍼스 · 스타터

빈 뼈대 + 그림 엔진 + 검증된 설정. 기능은 수업 시간에 Claude Code와 같이 만든다.

- `frontend/src/engine/` : 캐릭터 그림 엔진 (픽셀아트 파츠는 손으로 다듬은 것이라 그대로 쓴다)
- `e2e/playwright.config.ts` : E2E 설정 (서버 8081 + 화면 5174 + DB campus_e2e 를 자동으로 띄운다. 테스트는 직접 만든다)
- `reference/items.ts`   : 가구 공방(Day 2)에서 참고할 가구 템플릿 그림
- `deploy/`              : AWS 배포(Day 3) 설정 파일과 안내서

## 실행

```bash
docker compose up -d                        # MySQL
cd backend && ./gradlew bootRun             # 서버 8080 (윈도우 PowerShell: .\gradlew bootRun)
cd frontend && npm install && npm run dev   # 화면 5173
```
