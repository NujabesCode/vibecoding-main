// 스타터 화면. STEP 1에서 Claude가 이 파일을 바꾼다.
export default function App() {
  return (
    <main className="starter">
      <h1>우리반 캠퍼스</h1>
      <p>준비 완료! 이제 Claude Code에게 첫 프롬프트를 보내세요.</p>
    </main>
  );
}
